---
name: FazalDataConverter
colors:
  surface: '#faf8ff'
  surface-dim: '#d2d9f4'
  surface-bright: '#faf8ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f3ff'
  surface-container: '#eaedff'
  surface-container-high: '#e2e7ff'
  surface-container-highest: '#dae2fd'
  on-surface: '#131b2e'
  on-surface-variant: '#464555'
  inverse-surface: '#283044'
  inverse-on-surface: '#eef0ff'
  outline: '#777587'
  outline-variant: '#c7c4d8'
  surface-tint: '#4d44e3'
  primary: '#3525cd'
  on-primary: '#ffffff'
  primary-container: '#4f46e5'
  on-primary-container: '#dad7ff'
  inverse-primary: '#c3c0ff'
  secondary: '#712ae2'
  on-secondary: '#ffffff'
  secondary-container: '#8a4cfc'
  on-secondary-container: '#fffbff'
  tertiary: '#7e3000'
  on-tertiary: '#ffffff'
  tertiary-container: '#a44100'
  on-tertiary-container: '#ffd2be'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e2dfff'
  primary-fixed-dim: '#c3c0ff'
  on-primary-fixed: '#0f0069'
  on-primary-fixed-variant: '#3323cc'
  secondary-fixed: '#eaddff'
  secondary-fixed-dim: '#d2bbff'
  on-secondary-fixed: '#25005a'
  on-secondary-fixed-variant: '#5a00c6'
  tertiary-fixed: '#ffdbcc'
  tertiary-fixed-dim: '#ffb695'
  on-tertiary-fixed: '#351000'
  on-tertiary-fixed-variant: '#7b2f00'
  background: '#faf8ff'
  on-background: '#131b2e'
  surface-variant: '#dae2fd'
typography:
  display-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 30px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 26px
    letterSpacing: -0.005em
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: 0em
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0em
  body-sm:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
    letterSpacing: 0em
  label-lg:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
    letterSpacing: 0.005em
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.04em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  margin: 2rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
---

## Brand & Style

FazalDataConverter is a precision data conversion web application built for developers, data analysts, and technical teams who transform structured datasets between Excel, JSON, BSON, and static JS. The interface should evoke clarity, reliability, and effortless control—turning complex format conversions into a calm, predictable workflow.

This design system adopts a **Modern Minimal SaaS** style:
- **Clean, airy surfaces** with generous whitespace to reduce cognitive load during dense data inspection.
- **High-legibility typography** paired with crisp, restrained accents so interactive controls and status indicators stand out immediately.
- **Subtle structural boundaries** using hairline borders and soft, diffused elevation rather than heavy chrome.

## Colors

The palette is anchored in a bright, neutral light mode that prioritizes data legibility and long-session comfort:

- **Primary (`#4F46E5` Indigo):** Used for primary CTAs (e.g., *Convert*, *Export*), active navigation states, focus rings, and key interactive highlights.
- **Secondary (`#7C3AED` Violet):** Reserved for subtle secondary accents, format badges, or gradient/hover nuances that complement Indigo without competing with it.
- **Surfaces & Backgrounds:**
  - **Primary Surface (`#FFFFFF`):** Cards, modals, data tables, and input fields.
  - **Canvas Background (`#F8FAFC`):** The underlying application shell and secondary panels, creating a gentle separation from elevated white cards.
- **Text & Borders:**
  - **Primary Text (`#0F172A` Dark Charcoal):** Headings, table cell values, and primary labels.
  - **Secondary Text (`#475569` Neutral Slate):** Helper text, column headers, metadata, and inactive states.
  - **Borders & Dividers (`#E2E8F0` Subtle Grey):** 1px structural lines for tables, inputs, and card boundaries.
- **Semantic Colors:**
  - **Success (`#10B981` Emerald):** Validated schemas, completed conversions, and positive status pills.
  - **Warning (`#F59E0B` Amber):** Partial conversions, type-coercion notices, or large-file advisories.
  - **Error (`#EF4444` Rose):** Malformed JSON/BSON syntax errors, failed uploads, and destructive actions.

## Typography

The typography pairs **Plus Jakarta Sans** for headings with **Inter** for body copy, UI labels, and tabular data.

- **Headings (`Plus Jakarta Sans`):** Provides a modern, geometric warmth that gives the workspace an approachable SaaS feel. Tight negative letter-spacing (`-0.01em` to `-0.02em`) keeps multi-word titles compact and authoritative.
- **Body & UI (`Inter`):** Chosen for its exceptional legibility at small sizes (`13px`–`14px`), tall x-height, and clean numeric rendering. Enable `font-variant-numeric: tabular-nums` on all data tables, file sizes, row counts, and timestamps so columns align vertically.
- **Responsive Scaling:** `display-lg` (`36px`) scales down to `display-lg-mobile` (`28px`) on viewports below `640px` to prevent awkward line wrapping on mobile screens.

## Layout & Spacing

The layout is built on an **8pt (`0.5rem`) spacing grid** within a **12-column fluid grid** capped at a comfortable `1280px` max-width for main workspace views.

- **Desktop (`>= 1024px`):** 12-column grid with `1.5rem` (`24px`) gutters and `2rem` (`32px`) outer margins. Split-pane conversion views (e.g., source input on the left, target preview on the right) typically span 6 columns each.
- **Tablet (`640px – 1023px`):** 8-column grid with `1.5rem` gutters and `1.5rem` outer margins. Side-by-side conversion panes stack vertically when horizontal space constrains table readability.
- **Mobile (`< 640px`):** 4-column grid with `1rem` (`16px`) gutters and `1rem` outer margins. All multi-column forms and data previews collapse into single-column cards with horizontal scroll containers for wide data tables.

## Elevation & Depth

Visual hierarchy relies on a restrained combination of **tonal surface separation** and **ambient shadows**, avoiding heavy drop shadows or thick borders:

- **Base Canvas (`#F8FAFC`):** Sits at elevation 0.
- **Cards & Data Tables (`#FFFFFF`):** Sit at elevation 1, defined by a crisp `1px solid #E2E8F0` border and a subtle ambient shadow (`0 1px 3px 0 rgba(15, 23, 42, 0.06), 0 1px 2px -1px rgba(15, 23, 42, 0.04)`).
- **Dropdowns, Popovers & Modals:** Sit at elevation 2–3 with a slightly deeper, diffused shadow (`0 10px 25px -5px rgba(15, 23, 42, 0.08), 0 4px 10px -6px rgba(15, 23, 42, 0.04)`) and a `1px solid #E2E8F0` hairline border to maintain crispness against white surfaces.

## Shapes

The design system uses a **Rounded (`8px`–`12px`)** shape language that softens technical data workflows without feeling overly playful:

- **Standard UI Elements (`0.5rem` / `8px`):** Buttons, text inputs, select dropdowns, and table containers.
- **Large Containers (`0.75rem`–`1rem` / `12px`–`16px`):** Upload dropzones, conversion workspace cards, and modal dialogs.
- **Pills & Badges (`9999px`):** Format tags (`JSON`, `BSON`, `XLSX`, `JS`) and semantic status indicators.

## Components

- **Buttons:**
  - *Primary:* Solid `#4F46E5` fill, `#FFFFFF` text (`label-lg`), `8px` radius, `10px 16px` padding. Hover darkens slightly; focus displays a `2px` `#4F46E5` ring with `2px` offset.
  - *Secondary:* `#FFFFFF` fill, `1px solid #E2E8F0` border, `#0F172A` text. Hover shifts background to `#F8FAFC`.
  - *Ghost / Icon:* Transparent background, `#475569` icon/text, `#F8FAFC` hover fill.
- **Chips & Format Badges:** Compact `6px`–`8px` horizontal padding, `label-md` typography, full pill radius. Use subtle tinted backgrounds (e.g., `#EEF2FF` with `#4F46E5` text for active formats, or semantic tints for `Success`/`Warning`/`Error` states).
- **Input Fields & Selects:** `#FFFFFF` background, `1px solid #E2E8F0` border, `8px` radius, `10px 12px` padding. Placeholder text in `#94A3B8`; active focus transitions border to `#4F46E5` with a soft `3px` Indigo focus halo.
- **Checkboxes & Radio Buttons:** `16px`–`18px` hitboxes with `4px` radius (checkbox) or full circle (radio), `1px solid #CBD5E1` border, and `#4F46E5` fill when checked. Always pair with `label-lg` text and `8px` gap.
- **Cards:** `#FFFFFF` surface, `1px solid #E2E8F0` border, `12px` radius, `24px` (`space-lg`) internal padding, and elevation-1 ambient shadow.
- **Data Tables (Product-Specific):**
  - Sticky header row with `#F8FAFC` background, `#475569` `label-md` uppercase/medium text, and `1px solid #E2E8F0` bottom border.
  - Body rows on `#FFFFFF` with `12px 16px` cell padding, `tabular-nums` alignment, and `#F8FAFC` hover highlight.
- **File Dropzone (Product-Specific):** Dashed `2px` `#CBD5E1` border on `#F8FAFC` background with `12px` radius; transitions to `#4F46E5` border and `#EEF2FF` tint on drag-over.